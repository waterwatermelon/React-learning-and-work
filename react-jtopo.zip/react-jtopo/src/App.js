import './App.css';
import STopoTest from './lib/STopoTest'; 

function App() {


  return (
    <div className="App"> 
      <STopoTest />
    </div>
  );
}

export default App;
